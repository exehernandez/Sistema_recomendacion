from flask import Flask, render_template, request
import pickle
from collections import defaultdict

app = Flask(__name__)

# Cargar el modelo al inicio de la aplicación
with open('model_knn.pickle', 'rb') as model_file:
    model = pickle.load(model_file)

@app.route('/')
def index():
    return '¡Hola, mundo!'

@app.route('/recomendar', methods=['POST'])
def recomendar():
    user_id = int(request.form['user_id'])

    # Obtener recomendaciones para el usuario
    recommendations = get_recommendations(user_id)

    return render_template('resultados.html', user_id=user_id, recommendations=recommendations)

def get_recommendations(user_id):
    # Hacer las mismas operaciones que en tu script original
    anti_testset = model.trainset.build_anti_testset()
    all_predictions = model.test(anti_testset)
    user_recommendations = defaultdict(list)

    for pred in all_predictions:
        user_recommendations[pred.uid].append((pred.iid, pred.est))

    for _, recommendations in user_recommendations.items():
        recommendations.sort(key=lambda x: x[1], reverse=True)
        
        user_watched_animes = set(model.trainset.ur[model.trainset.to_inner_uid(user_id)])
        recommendations = [anime_id for anime_id, _ in recommendations if anime_id not in user_watched_animes]
    
    return recommendations

if __name__ == '__main__':
    app.run(debug=True)